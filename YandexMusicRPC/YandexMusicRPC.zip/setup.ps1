﻿<#
    Установка userplugin'ов Vencord из папки src рядом со скриптом.
    Каждая подпапка src с index.tsx считается отдельным плагином.
    Запускается через install.bat / update.bat / unpatch.bat.

    Патчит Discord сам, без скачивания VencordInstallerCli.exe с GitHub
    (раздача релизов GitHub часто недоступна). Делает ровно то же, что
    установщик Vencord: переименовывает resources\app.asar в _app.asar и
    кладёт на его место крошечный asar с одной строкой
    require("<путь>\dist\patcher.js").

    Параметры:
      -Update           только пересобрать (Discord не трогаем)
      -Unpatch          откатить патч Discord
      -Pack             собрать раздаточный набор + выкладку для самообновления
      -Version          версия набора (по умолчанию — дата и время сборки)
      -Notes            что нового; при -Pack спросит, если не задано
      -VencordPath      куда класть исходники Vencord (по умолчанию %USERPROFILE%\Vencord)
#>
param(
    [switch] $Update,
    [switch] $Unpatch,
    [switch] $Pack,
    [switch] $All,
    [string] $VencordPath,
    [string] $Version,
    [string] $Notes,
    [switch] $NoWait
)

try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }
$ErrorActionPreference = "Stop"

# иначе corepack может спросить подтверждение на скачивание pnpm и подвиснуть
$env:COREPACK_ENABLE_DOWNLOAD_PROMPT = "0"

$Root       = $PSScriptRoot
$Src        = Join-Path $Root "src"
$Vencord    = if ($VencordPath) { $VencordPath } else { Join-Path $env:USERPROFILE "Vencord" }
$BackupName = "app.asar.before-fakegameactivity"

function Say  ($m) { Write-Host $m }
function Step ($m) { Write-Host ""; Write-Host "[*] $m" -ForegroundColor Cyan }
function Ok   ($m) { Write-Host "[+] $m" -ForegroundColor Green }
function Warn ($m) { Write-Host "[!] $m" -ForegroundColor Yellow }
function Line ()   { Write-Host ("=" * 62) -ForegroundColor DarkGray }
function Have ($n) { [bool] (Get-Command $n -ErrorAction SilentlyContinue) }
function Hold () { if (-not $NoWait) { Read-Host "Нажми Enter, чтобы закрыть" | Out-Null } }

<#
    Архив собираем поэлементно, а не готовыми обёртками.

    Compress-Archive в PowerShell 5.1 и ZipFile.CreateFromDirectory в .NET
    Framework пишут пути через обратный слэш, хотя спецификация zip требует
    прямой: распаковщики ругаются, а некоторые создают файл с буквальным
    именем "dist\patcher.js". Здесь имя записи задаётся вручную, и кодировка
    имён явно UTF-8 — иначе «ЧИТАЙ МЕНЯ.txt» доезжает кракозябрами.
#>
function New-Zip ($SourceDir, $ZipPath) {
    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.File]::Delete($ZipPath)

    $base = (Resolve-Path $SourceDir).Path.TrimEnd("\") + "\"
    $fs = [IO.File]::Open($ZipPath, [IO.FileMode]::CreateNew)
    try {
        $zip = New-Object IO.Compression.ZipArchive($fs, [IO.Compression.ZipArchiveMode]::Create, $false, [Text.Encoding]::UTF8)
        try {
            foreach ($f in Get-ChildItem $SourceDir -Recurse -File) {
                $rel = $f.FullName.Substring($base.Length).Replace("\", "/")
                $out = $zip.CreateEntry($rel, [IO.Compression.CompressionLevel]::Optimal).Open()
                try {
                    $in = [IO.File]::OpenRead($f.FullName)
                    try { $in.CopyTo($out) } finally { $in.Dispose() }
                } finally { $out.Dispose() }
            }
        } finally { $zip.Dispose() }
    } finally { $fs.Dispose() }
}
function Fail ($m) {

    Write-Host ""
    Write-Host "[X] $m" -ForegroundColor Red
    Write-Host ""
    Hold
    exit 1
}

# ── работа с asar ─────────────────────────────────────────────────────
# Порт WriteAppAsar из установщика Vencord (Vencord/Installer, app_asar.go).
# Проверено: на одинаковом пути даёт байт в байт тот же файл.
function New-AppAsar {
    param([string] $OutFile, [string] $PatcherPath)

    $packageJson = "{`n`t`"name`": `"discord`",`n`t`"main`": `"index.js`"`n}"
    $indexJs     = "require(" + (ConvertTo-Json $PatcherPath) + ")"

    $indexLen = [Text.Encoding]::UTF8.GetByteCount($indexJs)
    $pkgLen   = [Text.Encoding]::UTF8.GetByteCount($packageJson)

    $header = [ordered] @{
        files = [ordered] @{
            "index.js"     = [ordered] @{ size = $indexLen; offset = "0" }
            "package.json" = [ordered] @{ size = $pkgLen;   offset = "$indexLen" }
        }
    }
    $headerString     = ConvertTo-Json $header -Compress -Depth 5
    $headerStringSize = [Text.Encoding]::UTF8.GetByteCount($headerString)

    $dataSize         = 4
    $alignedSize      = ($headerStringSize + $dataSize - 1) -band (-bnot ($dataSize - 1))
    $headerSize       = $alignedSize + 8
    $headerObjectSize = $alignedSize + $dataSize
    $pad              = $alignedSize - $headerStringSize
    if ($pad -gt 0) { $headerString += ("0" * $pad) }

    $ms = New-Object IO.MemoryStream
    $bw = New-Object IO.BinaryWriter($ms)
    try {
        foreach ($n in @($dataSize, $headerSize, $headerObjectSize, $headerStringSize)) {
            $bw.Write([int] $n)
        }
        $bw.Write([Text.Encoding]::UTF8.GetBytes($headerString))
        $bw.Write([Text.Encoding]::UTF8.GetBytes($indexJs))
        $bw.Write([Text.Encoding]::UTF8.GetBytes($packageJson))
        $bw.Flush()
        [IO.File]::WriteAllBytes($OutFile, $ms.ToArray())
    } finally {
        $bw.Dispose(); $ms.Dispose()
    }
}

# Куда указывает подменённый app.asar (или $null, если это оригинал Discord)
function Get-PatchTarget ($appAsar) {
    if (-not (Test-Path $appAsar)) { return $null }
    if ((Get-Item $appAsar).Length -gt 65536) { return $null }
    $text = [IO.File]::ReadAllText($appAsar)
    if ($text -match 'require\("(.+?)"\)') { return ($Matches[1] -replace '\\\\', '\') }
    return $null
}

# ── поиск Discord ─────────────────────────────────────────────────────
function Get-DiscordInstalls {
    $branches = [ordered] @{
        "Discord"            = "Discord"
        "DiscordPTB"         = "Discord PTB"
        "DiscordCanary"      = "Discord Canary"
        "DiscordDevelopment" = "Discord Development"
    }

    foreach ($dir in $branches.Keys) {
        $base = Join-Path $env:LOCALAPPDATA $dir
        if (-not (Test-Path $base)) { continue }

        $newest = Get-ChildItem $base -Directory -Filter "app-*" -ErrorAction SilentlyContinue |
            Sort-Object { try { [version] ($_.Name -replace '^app-', '') } catch { [version] "0.0.0" } } |
            Select-Object -Last 1
        if (-not $newest) { continue }

        $res = Join-Path $newest.FullName "resources"
        if (-not (Test-Path (Join-Path $res "app.asar"))) { continue }

        [pscustomobject] @{
            Title     = $branches[$dir]
            Process   = $dir
            Resources = $res
        }
    }
}

function Close-Discord ($installs) {
    $running = @($installs | ForEach-Object { Get-Process -Name $_.Process -ErrorAction SilentlyContinue })
    if (-not $running) { return }

    Write-Host ""
    Warn "Discord сейчас запущен, а патчить можно только закрытый."
    $answer = Read-Host "Закрыть Discord? [Enter — да, n — выйти]"
    if ($answer -match '^\s*[nNнН]') {
        Fail "Ок. Закрой Discord сам и запусти скрипт заново."
    }
    $running | Stop-Process -Force
    Start-Sleep -Seconds 2
    Ok "Discord закрыт."
}

function Set-DiscordPatch ($install, $patcherJs) {
    $app    = Join-Path $install.Resources "app.asar"
    $orig   = Join-Path $install.Resources "_app.asar"
    $backup = Join-Path $install.Resources $BackupName
    $isStub = (Get-Item $app).Length -lt 65536

    if (Test-Path $orig) {
        # уже пропатчен (нами или установщиком Vencord) — оригинал не трогаем
        if ($isStub -and -not (Test-Path $backup)) {
            Copy-Item $app $backup -Force
            Say "    прежняя заглушка сохранена как $BackupName"
        }
    } else {
        if ($isStub) {
            Fail "$($install.Title): app.asar подозрительно мал, но _app.asar рядом нет. Переустанови Discord."
        }
        Move-Item $app $orig
        Say "    оригинал app.asar переименован в _app.asar"
    }

    New-AppAsar -OutFile $app -PatcherPath $patcherJs
    Ok "$($install.Title) пропатчен -> $patcherJs"
}

function Invoke-PatchDiscord ($patcherJs) {
    $installs = @(Get-DiscordInstalls)
    if (-not $installs) { Fail "Не нашёл Discord в $env:LOCALAPPDATA. Он точно установлен?" }

    # трогаем только то, что реально нужно пропатчить: после обновления Discord
    # появляется новая папка app-<версия> уже без патча, а старая остаётся с ним
    $todo = @()
    foreach ($i in $installs) {
        if ((Get-PatchTarget (Join-Path $i.Resources "app.asar")) -eq $patcherJs) {
            Ok "$($i.Title) уже указывает на эту сборку, не трогаю."
        } else {
            $todo += $i
        }
    }
    if ($todo.Count -eq 0) { return }

    foreach ($i in $todo) {
        try {
            Set-DiscordPatch $i $patcherJs
        } catch {
            # файлы заняты запущенным Discord — закрываем и пробуем ещё раз
            Warn "Не вышло с первого раза: $($_.Exception.Message)"
            Close-Discord $installs
            Set-DiscordPatch $i $patcherJs
        }
    }
}

function Invoke-UnpatchDiscord {
    $installs = @(Get-DiscordInstalls)
    if (-not $installs) { Fail "Не нашёл Discord в $env:LOCALAPPDATA." }

    Close-Discord $installs

    foreach ($i in $installs) {
        $app    = Join-Path $i.Resources "app.asar"
        $orig   = Join-Path $i.Resources "_app.asar"
        $backup = Join-Path $i.Resources $BackupName

        if (Test-Path $backup) {
            Move-Item $backup $app -Force
            Ok "$($i.Title): вернул прежнюю сборку Vencord."
        } elseif (Test-Path $orig) {
            Remove-Item $app -Force
            Move-Item $orig $app
            Ok "$($i.Title): Vencord убран, Discord как из коробки."
        } else {
            Say "$($i.Title): патча не было, пропускаю."
        }
    }
}

# ── откат ─────────────────────────────────────────────────────────────
if ($Unpatch) {
    Write-Host ""
    Line
    Say "  Откат патча Discord"
    Line
    Invoke-UnpatchDiscord
    Write-Host ""
    Say "Запусти Discord — он вернулся в прежнее состояние."
    Write-Host ""
    Hold
    exit 0
}

# ── готовая сборка ────────────────────────────────────────────────────
# Если рядом со скриптом лежит папка dist — значит это уже собранный
# вариант: ни Node.js, ни git, ни исходников Vencord тут не нужно,
# остаётся только показать Discord, откуда её брать.
$ReadyPatcher = Join-Path $Root "dist\patcher.js"
if (Test-Path $ReadyPatcher) {
    Write-Host ""
    Line
    Say "  Готовая сборка Vencord с плагинами"
    Say "  Собирать ничего не нужно — просто подключаю её к Discord."
    Line

    Step "Патчу Discord..."
    Invoke-PatchDiscord $ReadyPatcher

    Write-Host ""
    Line
    Say "  Готово. Запусти Discord и открой:"
    Say "  Настройки -> Vencord -> Plugins"
    Say ""
    Say "  Откатить всё обратно можно через unpatch.bat."
    Line
    Write-Host ""
    Hold
    exit 0
}

Write-Host ""
Line
Say "  Плагины Vencord — $(if ($Pack) { 'сборка раздаточного набора' } elseif ($Update) { 'пересборка' } else { 'установка' })"
Say "  Исходники Vencord: $Vencord"
Line

# ── 1. окружение ──────────────────────────────────────────────────────

<#
    Ставим недостающее через winget — это встроенный в Windows магазин пакетов,
    он берёт установщики у самих разработчиков (Git.Git — The Git Development
    Community, OpenJS.NodeJS.LTS — Node.js Foundation). Никаких сторонних
    зеркал: то, что потом попадёт в сборку твоего Discord, качать откуда попало
    нельзя. Спрашиваем разрешение, потому что это изменение системы.
#>
function Install-Tool ($exe, $wingetId, $human, $fallbackPath) {
    if (Have $exe) { return $true }

    Write-Host ""
    Warn "$human не найден."
    if (-not (Have winget)) {
        Say "    winget в системе тоже нет — поставить автоматически не получится."
        return $false
    }

    $answer = Read-Host "Поставить $human автоматически через winget? [Enter — да, n — поставлю сам]"
    if ($answer -match '^\s*[nNнН]') { return $false }

    Step "Ставлю $human ($wingetId)..."
    & winget install --id $wingetId -e --source winget `
        --accept-package-agreements --accept-source-agreements --disable-interactivity

    # PATH у уже запущенного процесса сам не обновляется — перечитываем из реестра
    $env:Path = [Environment]::GetEnvironmentVariable("Path", "Machine") + ";" +
                [Environment]::GetEnvironmentVariable("Path", "User")
    if ((-not (Have $exe)) -and $fallbackPath -and (Test-Path $fallbackPath)) {
        $env:Path = (Split-Path $fallbackPath) + ";" + $env:Path
    }

    if (Have $exe) {
        Ok "$human поставлен."
        return $true
    }
    Warn "winget отработал, но $exe в PATH не появился — возможно, нужен перезапуск."
    return $false
}

if (-not (Install-Tool "git" "Git.Git" "git" "C:\Program Files\Git\cmd\git.exe")) {
    Fail "Без git не обойтись. Поставь вручную: https://git-scm.com/download/win"
}
if (-not (Install-Tool "node" "OpenJS.NodeJS.LTS" "Node.js" "C:\Program Files\nodejs\node.exe")) {
    Fail "Без Node.js не обойтись. Поставь версию LTS: https://nodejs.org/"
}

$nodeMajor = 0
if ((& node -v) -match "^v(\d+)") { $nodeMajor = [int] $Matches[1] }
if ($nodeMajor -lt 20) {
    Warn "Node.js v$nodeMajor слишком старый, Vencord требует 20 или новее."
    if (Have winget) {
        $answer = Read-Host "Обновить Node.js через winget? [Enter — да, n — обновлю сам]"
        if ($answer -notmatch '^\s*[nNнН]') {
            Step "Обновляю Node.js..."
            & winget install --id OpenJS.NodeJS.LTS -e --source winget `
                --accept-package-agreements --accept-source-agreements --disable-interactivity
            $env:Path = [Environment]::GetEnvironmentVariable("Path", "Machine") + ";" +
                        [Environment]::GetEnvironmentVariable("Path", "User")
            if ((& node -v) -match "^v(\d+)") { $nodeMajor = [int] $Matches[1] }
        }
    }
    if ($nodeMajor -lt 20) { Fail "Node.js всё ещё v$nodeMajor. Обнови вручную: https://nodejs.org/" }
}
Ok "Node.js v$nodeMajor и git на месте."

# pnpm: сначала глобальный, потом corepack, в крайнем случае ставим через npm
$PnpmCmd = $null
$PnpmPre = @()
if (Have pnpm) {
    $PnpmCmd = "pnpm"
} elseif (Have corepack) {
    $PnpmCmd = "corepack"
    $PnpmPre = @("pnpm")
} else {
    Step "pnpm не найден, ставлю через npm..."
    & npm i -g pnpm
    if (-not (Have pnpm)) { Fail "Не удалось установить pnpm. Попробуй вручную: npm i -g pnpm" }
    $PnpmCmd = "pnpm"
}
Ok "pnpm готов ($PnpmCmd)."

# Плагин — это подпапка src с файлом index.tsx.
# Обычно берём свою папку src, с ключом -All — все соседние проекты рядом:
# так один набор собирается сразу из всех плагинов, а не только из текущего.
$searchRoots = if ($All) {
    @(Get-ChildItem $Root -Directory -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName })
} else {
    @($Root)
}

$plugins = @()
foreach ($rootDir in $searchRoots) {
    $srcDir = Join-Path $rootDir "src"
    if (-not (Test-Path $srcDir)) { continue }
    $plugins += @(
        Get-ChildItem $srcDir -Directory -ErrorAction SilentlyContinue |
            Where-Object { Test-Path (Join-Path $_.FullName "index.tsx") }
    )
}

if ($plugins.Count -eq 0) {
    Fail $(if ($All) { "В подпапках $Root не нашлось ни одного плагина" } else { "В $Src нет ни одной папки плагина с index.tsx" })
}
Ok "Плагины: $(($plugins | ForEach-Object { $_.Name }) -join ', ')"

# ── 2. исходники Vencord ──────────────────────────────────────────────
if (Test-Path (Join-Path $Vencord "package.json")) {
    Step "Обновляю исходники Vencord..."
    Push-Location $Vencord
    & git pull --ff-only
    if ($LASTEXITCODE -ne 0) { Warn "git pull не прошёл — собираю из того, что есть." }
    Pop-Location
} else {
    if ($Update) {
        Fail "По пути $Vencord нет исходников Vencord. Сначала запусти install.bat"
    }
    Step "Скачиваю исходники Vencord (это займёт минуту)..."
    & git clone https://github.com/Vendicated/Vencord "$Vencord"
    if ($LASTEXITCODE -ne 0) { Fail "Не удалось склонировать репозиторий Vencord." }
}

# ── 3. копируем плагин ────────────────────────────────────────────────
$UserPlugins = Join-Path $Vencord "src\userplugins"
New-Item -ItemType Directory -Force -Path $UserPlugins | Out-Null

function Copy-Plugins ($list) {
    foreach ($p in $list) {
        $dest = Join-Path $UserPlugins $p.Name
        New-Item -ItemType Directory -Force -Path $dest | Out-Null
        Copy-Item -Path (Join-Path $p.FullName "*") -Destination $dest -Recurse -Force
        Say "    $($p.Name)"
    }
}

<#
    Для набора нужна сборка ровно из выбранных плагинов, а бандл у Vencord общий:
    что лежит в src\userplugins, то и попадёт внутрь. Поэтому на время упаковки
    убираем оттуда всё лишнее, а потом возвращаем и пересобираем — иначе твоя
    рабочая установка осталась бы без остальных плагинов.
#>
$stash = $null
if ($Pack) {
    $stash = Join-Path ([IO.Path]::GetTempPath()) ("vc-plugins-" + [guid]::NewGuid().ToString("N"))
    New-Item -ItemType Directory -Force -Path $stash | Out-Null
    foreach ($d in Get-ChildItem $UserPlugins -Directory -ErrorAction SilentlyContinue) {
        Move-Item $d.FullName (Join-Path $stash $d.Name) -Force
    }
    $stashed = @(Get-ChildItem $stash -Directory | ForEach-Object { $_.Name })
    if ($stashed.Count -gt 0) {
        Say "    (на время упаковки отложены: $($stashed -join ', '))"
    }
}

Step "Копирую плагины в src\userplugins"
Copy-Plugins $plugins

# ── 4. сборка ─────────────────────────────────────────────────────────
Set-Location $Vencord

Step "Ставлю зависимости (в первый раз это несколько минут)..."

# Одна зависимость Vencord живёт не в реестре npm, а прямо на GitHub (gifenc),
# и качается с codeload.github.com. У кого GitHub режется — установка спотыкается
# именно об неё, поэтому даём несколько попыток и внятно объясняем, если не вышло.
$installed = $false
foreach ($attempt in 1..3) {
    & $PnpmCmd ($PnpmPre + @("i"))
    if ($LASTEXITCODE -eq 0) { $installed = $true; break }
    if ($attempt -lt 3) {
        Warn "Попытка $attempt не удалась. Жду 5 секунд и пробую снова..."
        Start-Sleep -Seconds 5
    }
}

if (-not $installed) {
    Write-Host ""
    Warn "Проверяю, дело ли в зависимостях с GitHub..."
    $blocked = @()
    try {
        $pkg = Get-Content (Join-Path $Vencord "package.json") -Raw | ConvertFrom-Json
        foreach ($dep in $pkg.dependencies.PSObject.Properties) {
            if ($dep.Value -notlike "github:*") { continue }
            # github:owner/repo#commit -> ссылка на архив
            $spec = $dep.Value -replace "^github:", ""
            $repo, $ref = $spec -split "#", 2
            $url = "https://codeload.github.com/$repo/tar.gz/$ref"
            try {
                Invoke-WebRequest -UseBasicParsing -Method Head -TimeoutSec 25 $url | Out-Null
                Ok "  $($dep.Name): скачивается нормально"
            } catch {
                $blocked += $dep.Name
                Warn "  $($dep.Name): недоступен — $url"
            }
        }
    } catch { }

    if ($blocked.Count -gt 0) {
        Fail ("Не скачиваются зависимости с GitHub: " + ($blocked -join ", ") + ".`n" +
              "     Это блокировка доступа к codeload.github.com, а не ошибка сборки.`n" +
              "     Включи VPN или обход блокировок и запусти установку заново —`n" +
              "     скачанное попадёт в кеш pnpm, и дальше он больше не понадобится.")
    }
    Fail "pnpm i завершился с ошибкой. Текст ошибки выше."
}

Step "Собираю Vencord с плагином..."
& $PnpmCmd ($PnpmPre + @("build"))
if ($LASTEXITCODE -ne 0) { Fail "Сборка не удалась — текст ошибки выше." }

$patcherJs = Join-Path $Vencord "dist\patcher.js"
if (-not (Test-Path $patcherJs)) { Fail "Сборка прошла, но $patcherJs не появился." }
Ok "Сборка готова."

# ── набор для раздачи ─────────────────────────────────────────────────
if ($Pack) {
    # Discord читает из сборки ровно четыре файла — остальное это карты кода
    # и вариант для Vesktop, таскать их незачем
    $needed = @("patcher.js", "preload.js", "renderer.js", "renderer.css")
    $out = Join-Path $Root "ReadyBuild"
    $outDist = Join-Path $out "dist"
    $pluginList = ($plugins | ForEach-Object { "  - " + ($_.Name -replace '\.desktop$', '') }) -join "`r`n"

    Step "Собираю набор для раздачи в $out"
    if (Test-Path $out) { Remove-Item $out -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $outDist | Out-Null

    foreach ($f in $needed) {
        $from = Join-Path $Vencord "dist\$f"
        if (-not (Test-Path $from)) { Fail "В сборке нет файла $f" }
        Copy-Item $from $outDist -Force
    }
    Copy-Item $PSCommandPath $out -Force

    # ── выкладка для самообновления ───────────────────────────────────
    # Набор — это ровно те же четыре файла. Значит, обновить плагины у человека
    # можно, просто заменив их на диске: рядом кладём update.json (что за набор,
    # какая версия, где смотреть свежую), а в папку Publish — то, что надо
    # выложить в сеть. Плагин PluginUpdater у получателя читает манифест оттуда.
    $cfgPath = Join-Path $Root "update-config.json"
    $cfg = $null
    if (Test-Path $cfgPath) {
        try { $cfg = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json }
        catch { Warn "update-config.json не разобрался: $($_.Exception.Message)" }
    }

    $setVersion = if ($Version) { $Version } else { Get-Date -Format "yyyy.MM.dd.HHmm" }
    $setName = if ($cfg -and $cfg.name) { [string] $cfg.name } else { Split-Path $Root -Leaf }
    $base = if ($cfg -and $cfg.base) { ([string] $cfg.base).TrimEnd("/") } else { "" }
    $utf8 = New-Object Text.UTF8Encoding $false

    if (-not $base) {
        Warn "Самообновление не настроено: нет update-config.json с адресом выкладки."
        Say  "    Набор соберётся и так, но у получателя не будет кнопки «Обновить»."
    } elseif ($base -notmatch "^https://") {
        Warn "В update-config.json адрес не https — самообновление пропущено."
    } elseif ($base -match "ПОЛЬЗОВАТЕЛЬ|РЕПОЗИТОРИЙ") {
        Warn "В update-config.json остался пример адреса — впиши свой и запусти упаковку снова."
    } else {
        if (-not $PSBoundParameters.ContainsKey("Notes")) {
            Write-Host ""
            $Notes = Read-Host "Что нового в этой версии (Enter — пропустить)"
        }

        [IO.File]::WriteAllText((Join-Path $outDist "update.json"),
            ([ordered] @{
                name     = $setName
                version  = $setVersion
                manifest = "$base/manifest.json"
            } | ConvertTo-Json), $utf8)

        $fileMeta = [ordered] @{}
        foreach ($f in $needed) {
            $fp = Join-Path $outDist $f
            $fileMeta[$f] = [ordered] @{
                sha256 = (Get-FileHash $fp -Algorithm SHA256).Hash.ToLower()
                size   = [int] (Get-Item $fp).Length
            }
        }

        $pub = Join-Path $Root "Publish"
        $pubDist = Join-Path $pub "dist"
        if (Test-Path $pub) { Remove-Item $pub -Recurse -Force }
        New-Item -ItemType Directory -Force -Path $pubDist | Out-Null
        foreach ($f in $needed) { Copy-Item (Join-Path $outDist $f) $pubDist -Force }

        [IO.File]::WriteAllText((Join-Path $pub "manifest.json"),
            ([ordered] @{
                name    = $setName
                version = $setVersion
                notes   = $Notes
                baseUrl = "$base/dist/"
                files   = $fileMeta
            } | ConvertTo-Json -Depth 5), $utf8)

        Ok "Версия $setVersion. Выкладка готова в $pub"
    }

    # Запускалки для получателя пишем сами, а не копируем: в корне проекта они
    # называются иначе (install-all.bat), да и лишние ключи ему ни к чему.
    # Только ASCII — cmd.exe портит батники в UTF-8.
    $ascii = New-Object Text.ASCIIEncoding
    [IO.File]::WriteAllText((Join-Path $out "install.bat"), @"
@echo off
rem Connects the prebuilt Vencord to Discord. Nothing to compile.
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
"@, $ascii)
    [IO.File]::WriteAllText((Join-Path $out "unpatch.bat"), @"
@echo off
rem Reverts Discord to its original state.
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" -Unpatch
"@, $ascii)

    $readme = @"
Vencord с плагинами — готовая сборка
====================================

Ставить Node.js, git и что-либо ещё НЕ нужно: всё уже собрано.

В набор входят плагины:
__PLUGINS__

Установка:
  1. Запусти install.bat
  2. Когда спросит — разреши закрыть Discord
  3. Запусти Discord: Настройки -> Vencord -> Plugins, включи нужные плагины

Удалить: unpatch.bat вернёт Discord в исходное состояние.

Обновления: плагины следят за этим сами. Когда выйдет новая версия, в Discord
сверху появится полоска с кнопкой «Обновить» — нажми её и согласись на
перезапуск. Скидывать тебе файлы заново не нужно. Проверить вручную можно в
Настройки -> Vencord -> Plugins -> PluginUpdater.

Важно: не переноси эту папку после установки. Discord запоминает путь к ней,
и если папку сдвинуть, при следующем запуске он не найдёт сборку. Если всё же
перенёс — просто запусти install.bat заново из нового места.

Обновления Discord: если после его обновления плагины пропали, запусти
install.bat ещё раз.
"@
    # Приписка про конкретный набор, если она есть: сам шаблон общий на все
    # проекты, а рассказать хочется про особенности этого
    $note = Join-Path $Root "pack-note.txt"
    $extra = if (Test-Path $note) { "`r`n" + (Get-Content $note -Raw -Encoding UTF8).TrimEnd() + "`r`n" } else { "" }

    [IO.File]::WriteAllText((Join-Path $out "ЧИТАЙ МЕНЯ.txt"),
        $readme.Replace("__PLUGINS__", $pluginList) + $extra, (New-Object Text.UTF8Encoding $true))

    # Готовый архив для тех, кто ставит с нуля.
    # GitHub не умеет отдавать отдельную папку — только весь репозиторий целиком
    # или по одному файлу. Поэтому кладём рядом с выкладкой один zip: его видно
    # в списке файлов, и скачивается он кнопкой, без сторонних сервисов.
    # Внутри полный набор с install.bat, а не только файлы для обновления.
    if ($pub -and (Test-Path $pub)) {
        $zip = Join-Path $pub "$setName.zip"
        New-Zip $out $zip
        Ok "Архив для скачивания: $zip"
    }

    $size = [math]::Round((Get-ChildItem $out -Recurse -File | Measure-Object Length -Sum).Sum / 1MB, 1)

    # возвращаем отложенные плагины и пересобираем: твоя установка должна
    # остаться ровно такой, какой была до упаковки
    if ($stash -and (Test-Path $stash)) {
        $back = @(Get-ChildItem $stash -Directory)
        if ($back.Count -gt 0) {
            Step "Возвращаю на место остальные плагины и пересобираю..."
            Get-ChildItem $UserPlugins -Directory | Remove-Item -Recurse -Force
            foreach ($d in $back) { Move-Item $d.FullName (Join-Path $UserPlugins $d.Name) -Force }
            & $PnpmCmd ($PnpmPre + @("build"))
            if ($LASTEXITCODE -ne 0) { Warn "Пересборка не удалась — запусти update-all.bat вручную." }
            else { Ok "Твоя сборка восстановлена." }
        }
        Remove-Item $stash -Recurse -Force -ErrorAction SilentlyContinue
    }

    Write-Host ""
    Line
    Say "  Набор готов: $out"
    Say "  Размер: $size МБ. Можно архивировать и раздавать."
    Say ""
    Say "  У получателя ничего ставить не нужно — только запустить install.bat."
    if ($base -and (Test-Path (Join-Path $Root "Publish"))) {
        Say ""
        Say "  Чтобы разослать обновление, файлы никому пересылать не нужно:"
        Say "  выложи содержимое папки Publish по адресу"
        Say "    $base"
        Say "  так, чтобы открывался $base/manifest.json"
        Say "  Discord у получателей сам заметит новую версию и предложит обновиться."
    }
    Line
    Write-Host ""
    Hold
    exit 0
}

# ── 5. патч Discord ───────────────────────────────────────────────────
if ($Update) {
    # пересборка: патч уже указывает на эту же папку, трогать Discord не нужно
    $stale = @()
    foreach ($i in @(Get-DiscordInstalls)) {
        $target = Get-PatchTarget (Join-Path $i.Resources "app.asar")
        if ($target -ne $patcherJs) { $stale += $i.Title }
    }
    Write-Host ""
    Line
    if ($stale.Count -gt 0) {
        Warn "Discord ($($stale -join ', ')) не указывает на эту сборку — запусти install.bat"
    } else {
        Say "  Готово. Перезапусти Discord — или нажми Ctrl+R прямо в его окне."
    }
    Line
    Write-Host ""
    Hold
    exit 0
}

Step "Патчу Discord..."
Invoke-PatchDiscord $patcherJs

Write-Host ""
Line
Say "  Готово. Запусти Discord и открой:"
Say "  Настройки -> Vencord -> Plugins"
Say ""
Say "  Включи плагин тумблером и нажми на шестерёнку рядом,"
Say "  чтобы открыть его настройки. Установлено:"
foreach ($p in $plugins) { Say "    - $($p.Name)" }
Say ""
Say "  После обновлений Vencord запускай update.bat,"
Say "  а откатить патч Discord можно через unpatch.bat."
Line
Write-Host ""
Hold
