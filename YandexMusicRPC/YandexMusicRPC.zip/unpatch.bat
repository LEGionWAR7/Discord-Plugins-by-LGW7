@echo off
rem Reverts Discord to its original state.
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" -Unpatch