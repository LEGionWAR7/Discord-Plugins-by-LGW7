@echo off
rem Connects the prebuilt Vencord to Discord. Nothing to compile.
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"